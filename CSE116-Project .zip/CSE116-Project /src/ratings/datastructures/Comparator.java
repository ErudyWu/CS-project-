package ratings.datastructures;

public class Comparator<T> {
    //return true if a comes before b and false otherwise
    public  boolean compare(T a, T b) {
        return false;
    }
}
